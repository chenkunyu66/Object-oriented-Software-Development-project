#include "stdafx.h"
#include "Shape.h"

CShape::CShape()
{
	mSink = std::make_shared<CSink>();
}


CShape::~CShape()
{
}

void CShape::MoveRotation(double rotation, double radius)
{
	SetRotation(rotation);
}
