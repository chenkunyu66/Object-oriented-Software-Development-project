#include "stdafx.h"
#include "Sink.h"


CSink::CSink()
{
}

CSink::~CSink()
{
}
