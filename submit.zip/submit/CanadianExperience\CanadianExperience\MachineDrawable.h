/**
 * \file MachineDrawable.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Drawable.h"
#include "Machine.h"
#include "Timeline.h"
/**
* CMachineDrawable
*/
class CMachineDrawable :
	public CDrawable
{
public:

	///constructor
	CMachineDrawable(const std::wstring &name);

	///destructor
	virtual ~CMachineDrawable();

	/**
	* Draw
	* \param *graphics
	*/
	void Draw(Gdiplus::Graphics *graphics);

	/**
	* HitTest
	* \param pos
	* \return false
	*/
	bool HitTest(Gdiplus::Point pos);

	/**
	* SetTimeline
	* \param *timeline
	*/
	void SetTimeline(CTimeline *timeline);

	/**
	* SetKeyframe
	*/
	void SetKeyframe() {}

	/**
	* GetKeyframe
	*/
	void GetKeyframe() {}

	/**
	* SetMachineNumber
	* \param machine
	*/
	void SetMachineNumber(int machine);

	/**
	* GetMachine
	* \return mMachine
	*/
	std::shared_ptr<CMachine> GetMachine() { return mMachine; }
private:
	std::shared_ptr<CMachine> mMachine; ///< mMachine
	CTimeline* mTimeLine; ///< mTimeLine
};

