/**
 * \file Roller.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Component.h"
#include "Cam.h"
#include "Shape.h"
#include "WavChannel.h"

/**
* CRoller
*/
class CRoller :
	public CComponent
{
public:
	///contructor
	CRoller();

	/**
	* CRoller
	* \param radius
	* \param rotation
	*/
	CRoller(double radius, double rotation);

	/**
	* SetCam
	* \param cam
	*/
	void SetCam(std::shared_ptr<CCam> cam) { mCam = cam; }

	/**
	* Draw
	* \param *graphics
	* \param x
	* \param y
	*/
	void Draw(Gdiplus::Graphics *graphics, int x, int y);

	/**
	* AddPart
	* \param shape
	*/
	void AddPart(std::shared_ptr<CShape> shape) { mParts.push_back(shape); }

	/**
	* SetAudioChannel
	* \param channel
	*/
	void SetAudioChannel(std::shared_ptr<CWavChannel> channel) { mChannel = channel; }

	///destructor
	virtual ~CRoller();
private:
	double mRadius; ///< mRadius
	double mRotation; ///< mRotation
	std::vector<std::shared_ptr<CShape>> mParts; ///< mParts
	std::shared_ptr<CCam> mCam; ///< mCam
	std::shared_ptr<CWavChannel> mChannel; ///< mChannel
	bool mRing = false; ///< mRing
};

