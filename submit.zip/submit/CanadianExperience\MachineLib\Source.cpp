#include "stdafx.h"
#include "Source.h"


CSource::CSource()
{
}


CSource::~CSource()
{
}
