#include "stdafx.h"
#include "Roller.h"
#include <iostream>

CRoller::CRoller()
{
}

CRoller::CRoller(double radius, double rotation)
{
	mRadius = radius;
	mRotation = rotation;
	Circle(radius);
}

CRoller::~CRoller()
{
}

void CRoller::Draw(Gdiplus::Graphics *graphics, int x, int y)
{
	Gdiplus::PointF intersection;
	if (mCam->Intersection(mRotation, intersection))
	{
		float fx = intersection.X + mCam->GetPosition().X + x;
		float fy = intersection.Y + mCam->GetPosition().Y + y;

		CComponent::Draw(graphics, (int)fx, (int)fy);
		for (auto part : mParts)
		{
			part->SetPosition((int)fx - x, (int)fy - y);
		}

		double pinSize = mCam->GetPinSize();
		double offset = mCam->GetRadius() + pinSize - pinSize / 4;
		if (!mRing && abs(intersection.Y) >= offset)
		{
			mRing = true;
			mChannel->Play();
		}
		else if (mRing && abs(intersection.Y) < offset)
		{
			mRing = false;
		}
	}
}