/**
 * \file ActualMachine.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include <memory>
#include <vector>
#include "Component.h"
#include "WavPlayer.h"

/**
 * CActualMachine
 */
class CActualMachine
{
public:

	///contructor
	CActualMachine();
	///destructor
	virtual ~CActualMachine();
	/**
	* Set the position for the root of the machine
	* \param x X location (pixels)
	* \param y Y location (pixels)
	*/
	void SetLocation(int x, int y) { mLocation.X = x; mLocation.Y = y; }

	/**
	* Set the current machine animation frame
	* \param *graphics
	*/
	void DrawMachine(Gdiplus::Graphics *graphics);

	/**
	* Set the current machine animation frame
	* \param frame Frame number
	*/
	void SetMachineFrame(int frame) { mFrame = frame; }

	/**
	* Set  the speed
	* \param speed of the machine from 0 to 1
	*/
	void SetSpeed(double speed) { mSpeed = speed; }

	/**
	* Set the machine number
	* \param machine An integer number. Each integer makes a different machine
	*/
	void SetMachine(int machine);

	/**
	* Get the current machine number
	* \return Machine number
	*/
	virtual int GetMachine() { return mMachine; }

	/**
	*GetWavPlayer
	* \return mPlayer
	*/
	std::shared_ptr<CWavPlayer> GetWavPlayer() { return mPlayer; }
	/**
	* Addcomponent
	* \param component
	*/
	void AddComponent(std::shared_ptr<CComponent> component);
	/**
	*Settime
	* \param time
	*/
	void SetTime(double time);
private:
	std::vector<std::shared_ptr<CComponent>> mComponents; ///< mComponents
	Gdiplus::Point mLocation = { 0,0 }; ///< Machine location   
	int mFrame = 0; ///< Current frame
	double mSpeed = 0;  ///< Bend angle
	int mMachine = 1;  ///< Machine number
	std::shared_ptr<CWavPlayer> mPlayer; ///< mPlayer
};

