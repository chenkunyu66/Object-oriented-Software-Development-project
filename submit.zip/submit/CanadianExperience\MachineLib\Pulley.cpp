#include "stdafx.h"
#include "Pulley.h"


CPulley::CPulley()
{
}

CPulley::CPulley(double radius)
{
	CComponent();
	Circle(radius);
	mRadius = radius;
	mSource = std::make_shared<CSource>();
	mSink = std::make_shared<CSink>();
}


CPulley::~CPulley()
{
}

void CPulley::MoveRotation(double rotation, double radius)
{
	if (radius < 0)
	{
		SetRotation(rotation);
		mRotation = rotation;
	}
		
	else
	{
		mRotation = rotation * (radius / mRadius);
		SetRotation(mRotation);
	}
}

void CPulley::Drive(std::shared_ptr<CPulley> pulley)
{
	
	pulley->GetSink()->SetRadius(mRadius);
	GetSource()->AddSink(pulley->GetSink());
}

void CPulley::SetTime(double time)
{
	CComponent::SetTime(time);

	auto sinks = mSource->GetSinks();
	for (auto sink : sinks)
	{
		sink->GetComponent()->MoveRotation(mRotation, sink->GetRadius());
	}
}

void CPulley::Draw(Gdiplus::Graphics *graphics, int x, int y)
{
	auto sinks = mSource->GetSinks();
	for (auto sink : sinks)
	{
		if (sink->GetRadius() >= 0)
		{
			double r1 = GetRadius() - 3;
			double r2 = sink->GetComponent()->GetRadius() - 3;

			Gdiplus::Point p1 = GetPosition();
			Gdiplus::Point p2 = sink->GetComponent()->GetPosition();

			double theta = atan2(p2.Y - p1.Y, p2.X - p1.X);
			double distance = sqrt((p2.X - p1.X) * (p2.X - p1.X) + (p2.Y - p1.Y) * (p2.Y - p1.Y));
			double phi = asin((r2 - r1) / distance);

			double beta = theta + phi + M_PI / 2;
			Gdiplus::Pen blackPen(Gdiplus::Color(255, 0, 0, 0), 2);
			Gdiplus::Point pn1 = { (INT)(p1.X + r1 * cos(beta) + x), (INT)(p1.Y + r1 * sin(beta) + y) };
			Gdiplus::Point pn2 = { (INT)(p2.X + r2 * cos(beta) + x), (INT)(p2.Y + r2 * sin(beta) + y) };

			double beta2 = theta - phi - M_PI / 2;
			Gdiplus::Point pn3 = { (INT)(p1.X + r1 * cos(beta2) + x), (INT)(p1.Y + r1 * sin(beta2) + y) };
			Gdiplus::Point pn4 = { (INT)(p2.X + r2 * cos(beta2) + x), (INT)(p2.Y + r2 * sin(beta2) + y) };

			auto saveSM = graphics->GetSmoothingMode();
			graphics->SetSmoothingMode(Gdiplus::SmoothingMode::SmoothingModeHighQuality);

			graphics->DrawLine(&blackPen, pn1, pn2);
			graphics->DrawLine(&blackPen, pn3, pn4);

			graphics->SetSmoothingMode(saveSM);
		}
	}
	CComponent::Draw(graphics, x, y);
}