/**
 * \file Component.h
 *
 * \author Chenkunyu
 *
 * 
 */


#pragma once
#include "Polygon.h"

/**
 * CComponent
 */
class CComponent :
	public CPolygon
{
public:
	///contructor
	CComponent();
	///contructor
	virtual ~CComponent();

	/**
	* Draw
	* \param *graphics
	* \param x
	* \param y
	*/
	virtual void Draw(Gdiplus::Graphics *graphics, int x, int y);

	/**
	* SetPosition
	* \param x
	* \param y
	*/
	void SetPosition(int x, int y);

	/**
	* GetPosition
	* \return mPosition
	*/
	Gdiplus::Point GetPosition() { return mPosition; }

	/**
	* SetTime
	* \param time
	*/
	virtual void SetTime(double time) { mTime = time; }

	/**
	* MoveRotation
	* \param rotation
	* \param radius
	*/
	virtual void MoveRotation(double rotation, double radius) {}

	/**
	* GetRadius
	* \return 0.0
	*/
	virtual double GetRadius() { return 0.0; }

	/**
	* GetTime
	* \return mTime
	*/
	double GetTime() { return mTime; }
private:
	double mTime = 0; ///< mTime
	Gdiplus::Point mPosition = { 0,0 }; ///< mPosition
};

