/**
 * \file Sink.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include <memory>
#include "Component.h"

/**
* CSink
*/
class CSink
{
public:
	///contructor
	CSink();

	/**
	* GetComponent
	* \return mComponent
	*/
	std::shared_ptr<CComponent> GetComponent() { return mComponent; }

	/**
	* SetComponent
	* \param component
	*/
	void SetComponent(std::shared_ptr<CComponent> component) { mComponent = component; }

	/**
	* SetRadius
	* \param radius
	*/
	void SetRadius(double radius) { mRadius = radius; }

	/**
	* GetRadius
	* \return mRadius
	*/
	double GetRadius() { return mRadius; }

	///destructor
	virtual ~CSink();
private:
	double mRadius = -1; ///< mRadius
	std::shared_ptr<CComponent> mComponent; ///< mComponent
};

