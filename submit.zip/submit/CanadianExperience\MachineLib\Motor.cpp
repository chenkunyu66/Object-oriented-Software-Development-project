#include "stdafx.h"
#include "Motor.h"


CMotor::CMotor()
{
	mSource = std::make_shared<CSource>();
}


CMotor::~CMotor()
{
}

void CMotor::Draw(Gdiplus::Graphics * graphics, int x, int y)
{
	Gdiplus::Point position = GetPosition();
	auto base = std::make_shared<CPolygon>();
	base->Rectangle(- Size / 2, 0, Size, Size);
	base->SetImage(L"images/motor2.png");
	base->DrawPolygon(graphics, position.X + x, position.Y + y);

	auto shaft = std::make_shared<CPolygon>();
	shaft->Circle(8);
	shaft->SetImage(L"images/shaft.png");
	shaft->SetRotation(GetTime() * mSpeed);
	shaft->DrawPolygon(graphics, position.X + x, position.Y + y - Size / 2);
}

void CMotor::SetTime(double time)
{
	CComponent::SetTime(time);
	auto sinks = mSource->GetSinks();
	for (auto sink : sinks)
	{
		sink->GetComponent()->MoveRotation(time, -1);
	}
}