/**
 * \file PictureFactory.cpp
 *
 * \author Charles B. Owen
 */

#include "stdafx.h"
#include "PictureFactory.h"
#include "HaroldFactory.h"
#include "SpartyFactory.h"
#include "ImageDrawable.h"
#include "MachineDrawable.h"
#include "FlagFactory.h"

using namespace std;
using namespace Gdiplus;

/**
 * \brief Constructor
 */
CPictureFactory::CPictureFactory()
{
}

/**
 * \brief Destructor
 */
CPictureFactory::~CPictureFactory()
{
}


/*! \brief Factory method to create a new picture.
* \returns The created picture
*/
std::shared_ptr<CPicture> CPictureFactory::Create()
{
    shared_ptr<CPicture> picture = make_shared<CPicture>();

    // Create the background and add it
    auto background = make_shared<CActor>(L"Background");
    background->SetClickable(false);
    background->SetPosition(Point(-100, 0));
    auto backgroundI = make_shared<CImageDrawable>(L"Background", L"images/Background.png");
    background->AddDrawable(backgroundI);
    background->SetRoot(backgroundI);
    picture->AddActor(background);

	auto machineActor1 = std::make_shared<CActor>(L"machine1");
	auto machineDrawable1 = std::make_shared<CMachineDrawable>(L"machine1");
	machineDrawable1->SetMachineNumber(1);
	machineDrawable1->SetPosition(Gdiplus::Point(0, 0));
	machineActor1->SetRoot(machineDrawable1);
	machineActor1->AddDrawable(machineDrawable1);
	machineActor1->SetPosition(Gdiplus::Point(200, 400));
	picture->AddActor(machineActor1);
	picture->SetMachine1(machineDrawable1->GetMachine());

	auto machineActor2 = std::make_shared<CActor>(L"machine2");
	auto machineDrawable2 = std::make_shared<CMachineDrawable>(L"machine2");
	machineDrawable2->SetMachineNumber(2);
	machineDrawable2->SetPosition(Gdiplus::Point(0, 0));
	machineActor2->SetRoot(machineDrawable2);
	machineActor2->AddDrawable(machineDrawable2);
	machineActor2->SetPosition(Gdiplus::Point(600, 500));
	picture->AddActor(machineActor2);
	picture->SetMachine2(machineDrawable2->GetMachine());

	CFlagFactory factory1;
	auto flag = factory1.Create();
	flag->SetPosition(Point(200, 300));
	picture->AddActor(flag);

    // Create and add Harold
    CHaroldFactory factory;
    auto harold = factory.Create();

    // This is where Harold will start out.
    harold->SetPosition(Point(750, 500));

    picture->AddActor(harold);

    // Create and add Sparty
    CSpartyFactory sfactory;
    auto sparty = sfactory.Create();

    sparty->SetPosition(Point(520, 500));
    picture->AddActor(sparty);
	
    return picture;
}
