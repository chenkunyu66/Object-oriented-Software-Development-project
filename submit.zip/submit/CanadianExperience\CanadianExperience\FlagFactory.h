/**
 * \file FlagFactory.h
 *
 * \author kunyu chen
 *
 * \brief Factory that builds the Sparty actor.
 */

#pragma once
#include "ActorFactory.h"

/**
* \brief Factory that builds the Flag actor.
*/
class CFlagFactory : public CActorFactory
{
public:
	CFlagFactory();
	virtual ~CFlagFactory();

	std::shared_ptr<CActor> Create();
};

