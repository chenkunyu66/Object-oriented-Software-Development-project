/**
 * \file Source.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Sink.h"
#include <vector>
#include <memory>

/**
* CSource
*/
class CSource
{
public:

	///constructor
	CSource();

	///destructor
	virtual ~CSource();

	/**
	* AddSink
	* \param sink
	*/
	void AddSink(std::shared_ptr<CSink> sink) { mSinks.push_back(sink); }
	/**
	* GetSinks
	* \return mSinks
	*/
	std::vector<std::shared_ptr<CSink>> GetSinks() { return mSinks; }
private:
	std::vector<std::shared_ptr<CSink>> mSinks; ///< mSinks
};

