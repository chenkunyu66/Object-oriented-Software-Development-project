/**
 * \file Shape.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Component.h"
#include "Sink.h"

/**
* CShape
*/
class CShape :
	public CComponent
{
public:
	///constructor
	CShape();
	///destructor
	virtual ~CShape();

	/**
	* MoveRotation
	* \param rotation
	* \param radius
	*/
	void MoveRotation(double rotation, double radius);

	/**
	* GetSink
	* \return mSink
	*/
	std::shared_ptr<CSink> GetSink() { return mSink; }
private:
	std::shared_ptr<CSink> mSink; ///< mSink
};

