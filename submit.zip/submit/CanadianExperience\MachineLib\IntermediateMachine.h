/**
 * \file IntermediateMachine.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Machine.h"
#include "ActualMachine.h"
#include "Component.h"

/**
 * CIntermediateMachine
 */
class CIntermediateMachine :
	public CMachine
{
public:
	///constructor
	CIntermediateMachine();
	///destructor
	virtual ~CIntermediateMachine();

	/**
	* SetLocation
	* \param x
	* \param y
	*/
	void SetLocation(int x, int y);

	/**
	* DrawMachine
	* \param *graphics
	*/
	void DrawMachine(Gdiplus::Graphics *graphics);

	/**
	* SetMachineFrame
	* \param frame
	*/
	void SetMachineFrame(int frame);

	/**
	* SetFrameRate
	* \param rate
	*/
	void SetFrameRate(double rate);

	/**
	* SetSpeed
	* \param speed
	*/
	void SetSpeed(double speed);

	/**
	* SetMachineNumber
	* \param machine
	*/
	void SetMachineNumber(int machine);

	/**
	* GetMachineNumber
	* \return 
	*/
	int GetMachineNumber();

	/**
	* AddComponent
	* \param compoment
	*/
	void AddComponent(std::shared_ptr<CComponent> compoment);

	/**
	* GetWavPlayer
	* \return Machine number integer
	*/
	std::shared_ptr<CWavPlayer> GetWavPlayer();
private:
	double mTime = 0; ///< mTime
	double mFrameRate = 30; ///< mFrameRate
	int mFrame = 0; ///< mFrame
	std::shared_ptr<CActualMachine> mMachineActual; ///< mMachineActual
};

