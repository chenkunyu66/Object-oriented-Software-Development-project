/**
 * \file Cam.h
 *
 * \author Chenkunyu
 *
 * 
 */


#pragma once
#include "Component.h"
#include "Sink.h"

/**
 * CCam
 */
class CCam :
	public CComponent
{
public:
	///contructor
	CCam();
	/**
	* cCam
	* \param radius
	* \param steps
	*/
	CCam(double radius, int steps);
	///destructor
	virtual ~CCam();

	/**
	* Build
	*/
	void Build();
	/**
	* AddPin
	* \param pin
	*/
	void AddPin(int pin) { mPins.push_back(pin); }
	/**
	* MoveRotation
	* \param rotation
	* \param radius
	*/
	void MoveRotation(double rotation, double radius);
	/**
	* GetSink
	* \return mSink
	*/
	std::shared_ptr<CSink> GetSink() { return mSink; }

	/**
	* GetRadius
	* \return mRadius
	*/
	double GetRadius() { return mRadius; }
	/**
	* GetPinSize
	* \return mPinSize
	*/
	double GetPinSize() { return mPinSize; }
private:
	int mSteps; ///< mSteps
	double mRadius; ///< mRadius
	double mPinSize = 5; ///< mPinSize
	std::vector<int> mPins; ///< mPins
	std::shared_ptr<CSink> mSink; ///< mSink
};

