#include "stdafx.h"
#include "MachineDrawable.h"
#include "MachineFactory.h"

CMachineDrawable::CMachineDrawable(const std::wstring & name) : CDrawable(name)
{
	CMachineFactory factory;
	mMachine = factory.CreateMachine();
	mMachine->SetSpeed(1.0);
}

CMachineDrawable::~CMachineDrawable()
{
}

void CMachineDrawable::Draw(Gdiplus::Graphics *graphics)
{
	mMachine->SetMachineFrame(mTimeLine->GetCurrentFrame());

	float scale = 0.6f;

	auto save = graphics->Save();
	graphics->TranslateTransform((float)mPlacedPosition.X,
		(float)mPlacedPosition.Y);
	graphics->ScaleTransform(scale, scale);
	mMachine->DrawMachine(graphics);
	graphics->Restore(save);
}

bool CMachineDrawable::HitTest(Gdiplus::Point pos)
{
	return false;
}

void CMachineDrawable::SetTimeline(CTimeline * timeline)
{
	mTimeLine = timeline;
	mMachine->SetFrameRate(timeline->GetFrameRate());
}

void CMachineDrawable::SetMachineNumber(int machine)
{
	mMachine->SetMachineNumber(machine);
}
