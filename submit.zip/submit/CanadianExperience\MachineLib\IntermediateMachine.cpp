#include "stdafx.h"
#include "IntermediateMachine.h"

CIntermediateMachine::CIntermediateMachine()
{
	mMachineActual = std::make_shared<CActualMachine>();
	SetMachineNumber(1);
}


CIntermediateMachine::~CIntermediateMachine()
{
}

void CIntermediateMachine::SetLocation(int x, int y)
{
	mMachineActual->SetLocation(x, y);
}

void CIntermediateMachine::DrawMachine(Gdiplus::Graphics * graphics)
{
	mMachineActual->DrawMachine(graphics);
}

void CIntermediateMachine::SetMachineFrame(int frame)
{
	mMachineActual->SetMachineFrame(frame);
	mMachineActual->SetTime(double(frame) / mFrameRate);
}

void CIntermediateMachine::SetFrameRate(double rate)
{
	mFrameRate = rate;
}

void CIntermediateMachine::SetSpeed(double speed)
{
	mMachineActual->SetSpeed(speed);
}

void CIntermediateMachine::SetMachineNumber(int machine)
{
	mMachineActual->SetMachine(machine);
}

int CIntermediateMachine::GetMachineNumber()
{
	return mMachineActual->GetMachine();
}

void CIntermediateMachine::AddComponent(std::shared_ptr<CComponent> compoment)
{
	mMachineActual->AddComponent(compoment);
}

std::shared_ptr<CWavPlayer> CIntermediateMachine::GetWavPlayer()
{
	return mMachineActual->GetWavPlayer();
}
