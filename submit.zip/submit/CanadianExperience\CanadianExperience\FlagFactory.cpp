/**
 * \file FlagFactory.cpp
 *
 * \author kunyu chen
 */

#include "stdafx.h"
#include "FlagFactory.h"
#include "PolyDrawable.h"
#include "ImageDrawable.h"


using namespace Gdiplus;
using namespace std;

CFlagFactory::CFlagFactory()
{
}


CFlagFactory::~CFlagFactory()
{
}

/** \brief This is a concrete factory method that creates our Harold actor.
* \returns Pointer to an actor object.
*/
std::shared_ptr<CActor> CFlagFactory::Create()
{
	shared_ptr<CActor> actor = make_shared<CActor>(L"Flag");
	auto flag = make_shared<CImageDrawable>(L"Flag", L"images/msu_flag.png");
	flag->SetCenter(Point(44, 138));
	flag->SetPosition(Point(0, -114));
	actor->SetRoot(flag);
	actor->AddDrawable(flag);

	return actor;
}