#include "stdafx.h"
#include "Cam.h"

const int SubSteps = 3;
CCam::CCam()
{
}

CCam::CCam(double radius, int steps)
{
	CComponent::CComponent();
	mSink = std::make_shared<CSink>();
	mRadius = radius;
	mSteps = steps;
}

CCam::~CCam()
{
}

void CCam::Build()
{
	for (int i = 0; i < mSteps * SubSteps; i++)
	{
		double angle = 2 * M_PI * i / double(mSteps * SubSteps);
		double radius = mRadius;

		for (auto pin : mPins)
		{
			if (pin * SubSteps == i || pin * SubSteps == (i - 1))
			{
				radius = mRadius + mPinSize;
				break;
			}
		}

		AddPoint(radius * cos(angle), radius * -sin(angle));
	}
}

void CCam::MoveRotation(double rotation, double radius)
{
	SetRotation(rotation);
}