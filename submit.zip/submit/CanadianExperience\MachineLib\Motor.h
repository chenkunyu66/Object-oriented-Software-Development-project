/**
 * \file Motor.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Component.h"
#include "Source.h"

/**
 * CMoter
 */
class CMotor :
	public CComponent
{
public:
	///constructor
	CMotor();
	/// destructor
	virtual ~CMotor();


	static constexpr int Size = 80; ///< Size

	/**
	* SetSpeed
	* \param speed
	*/
	void SetSpeed(double speed) { mSpeed = speed; }

	/**
	* Draw
	* \param *graphics
	* \param x
	* \param y
	*/
	void Draw(Gdiplus::Graphics * graphics, int x, int y);

	/**
	* GetSource
	* \return mSource
	*/
	std::shared_ptr<CSource> GetSource() { return mSource; }

	/**
	* GetRotation
	* \return mRotation
	*/
	double GetRotation() { return mRotation; }

	/**
	* SetTime
	* \param time
	*/
	void SetTime(double time);
private:
	double mRotation = 0; ///< mRotation
	double mSpeed = 0; ///< mSpeed
	std::shared_ptr<CSource> mSource; ///< mSource
};

