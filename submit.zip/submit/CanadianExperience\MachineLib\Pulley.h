/**
 * \file Pulley.h
 *
 * \author Chenkunyu
 *
 * 
 */

#pragma once
#include "Component.h"
#include "Source.h"
#include "Sink.h"
/**
* CPulley
*/
class CPulley :
	public CComponent
{
public:
	///contructor
	CPulley();
    
	/**
	* CPulley
	* \param radius
	*/
	CPulley(double radius);

	///destructor
	virtual ~CPulley();

	/**
	* GetSource
	* \return mSource
	*/
	std::shared_ptr<CSource> GetSource() { return mSource; }

	/**
	* GetSink
	* \return mSink
	*/
	std::shared_ptr<CSink> GetSink() { return mSink; }

	/**
	* MoveRotation
	* \param rotation
	* \param radius
	*/
	void MoveRotation(double rotation, double radius);

	/**
	* Drive
	* \param pulley
	*/
	void Drive(std::shared_ptr<CPulley> pulley);

	/**
	* SetTime
	* \param time
	*/
	void SetTime(double time);

	/**
	* GetRadius
	* \return mRadius
	*/
	double GetRadius() { return mRadius; }

	/**
	* Draw
	* \param *graphics
	* \param x
	* \param y
	*/
	void Draw(Gdiplus::Graphics *graphics, int x, int y);
private:
	double mRadius; ///< mRadius
	double mRotation = 0; ///< mRotation
	std::shared_ptr<CSource> mSource; ///< mSource
	std::shared_ptr<CSink> mSink; ///< mSink
};

