#include "stdafx.h"
#include "ActualMachine.h"
#include "Shape.h"
#include "Motor.h"
#include "Pulley.h"
#include "WavPlayer.h"
#include "Cam.h"
#include "Roller.h"
#include <memory>

CActualMachine::CActualMachine()
{
	mPlayer = std::make_shared<CWavPlayer>();
}


CActualMachine::~CActualMachine()
{
}

void CActualMachine::DrawMachine(Gdiplus::Graphics * graphics)
{
	for (auto component : mComponents)
	{
		component->Draw(graphics, mLocation.X, mLocation.Y);
	}
}

void CActualMachine::SetMachine(int machine)
{
	mMachine = machine;
	if (mMachine == 1)
	{
		mComponents.clear();
		// The base
		auto base = std::make_shared<CShape>();
		int wid = 550;
		base->Rectangle(-wid / 2, 0, wid, 40);
		base->SetImage(L"images/base.png");
		AddComponent(base);

		// The motor
		auto motor = std::make_shared<CMotor>();
		motor->SetPosition(-150, -38);
		motor->SetSpeed(1.0);
		AddComponent(motor);

		// Post to hold the first pulley
		// Must be added before the motor pulley so it draws behind the belt
		auto post1 = std::make_shared<CShape>();
		post1->Rectangle(-210, -40, 20, 120);
		post1->SetColor(Gdiplus::Color::DarkBlue);
		AddComponent(post1);


		// The pulley driven by the motor
		// Radius=15pixels
		auto pulley1 = std::make_shared<CPulley>(15);
		pulley1->GetSink()->SetComponent(pulley1);
		pulley1->SetImage(L"images/pulley2.png");
		pulley1->SetPosition(-150, -38 - CMotor::Size / 2);
		pulley1->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley1);

		// This is how I make a connection from a source to a sink.
		// This is the case where they are driven at the same speed.
		motor->GetSource()->AddSink(pulley1->GetSink());

		// The pulley on the first post. Driven by the motor pulley.
		// Radius=40pixels
		auto pulley2 = std::make_shared<CPulley>(40);
		pulley2->GetSink()->SetComponent(pulley2);
		pulley2->SetImage(L"images/pulley.png");
		pulley2->SetPosition(-200, -150);
		pulley2->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley2);

		// This is how I make a connection from a pully
		// to another pully using a belt.
		pulley1->Drive(pulley2);

		// Pulley directly driven by that pulley
		// Radius=15px
		auto pulley3 = std::make_shared<CPulley>(15);
		pulley3->GetSink()->SetComponent(pulley3);
		pulley3->SetImage(L"images/pulley2.png");
		pulley3->SetPosition(-200, -150);
		AddComponent(pulley3);

		pulley2->GetSource()->AddSink(pulley3->GetSink());

		//
		// There are five bells we create, each consisting of:
		//
		// A post that holds the pulleys and cam
		// A pulley that is driven by the previous stage
		// A pulley to drive the next stage
		// A cam
		// A roller that rides on the cam
		// The mallet driven by the roller
		// The bell
		//

		// The pully that drives this bell
		auto drivePulley = pulley3;

		// X positions of each bell
		int bellX[] = { -100, -30, 40, 110, 190 };

		for (int i = 0; i < 5; i++)
		{
			int x = bellX[i];

			// A post that holds the pulleys and cam
			auto pully2post = std::make_shared<CShape>();
			pully2post->Rectangle(x - 10, -40, 20, 120);
			pully2post->SetColor(Gdiplus::Color::Brown);
			AddComponent(pully2post);

			// A pulley that is driven by the previous stage
			// Radius=35pixels
			auto drivenPulley = std::make_shared<CPulley>(35);
			drivenPulley->GetSink()->SetComponent(drivenPulley);
			drivenPulley->SetImage(L"images/pulley.png");
			drivenPulley->SetPosition(x, -150);
			AddComponent(drivenPulley);

			drivePulley->Drive(drivenPulley);

			// A pulley to drive the next stage
			drivePulley = std::make_shared<CPulley>(35);
			drivePulley->GetSink()->SetComponent(drivePulley);
			drivePulley->SetImage(L"images/pulley.png");
			drivePulley->SetPosition(x, -150);
			drivePulley->SetPhase(0.1);
			AddComponent(drivePulley);

			drivenPulley->GetSource()->AddSink(drivePulley->GetSink());

			// A cam
			auto cam = std::make_shared<CCam>(20, 16);
			cam->GetSink()->SetComponent(cam);
			cam->SetImage(L"images/hammered-copper1.png", true);
			cam->SetPhase(-0.25);
			cam->SetPosition(drivePulley->GetPosition().X, drivePulley->GetPosition().Y);

			AddComponent(cam);
			drivePulley->GetSource()->AddSink(cam->GetSink());

			// A roller that rides on the cam
			// Radius is 4 pixels.
			// The angle is 0.25, placing it at the top of the cam
			auto roller = std::make_shared<CRoller>(4, 0.25);
			roller->SetImage(L"images/roller.png");
			roller->SetCam(cam);
			AddComponent(roller);

			// A bar that represents the bell
			auto bar = std::make_shared<CShape>();
			bar->Rectangle(-24 / 2, 0, 24, 108);
			bar->SetPosition(x, -215);
			AddComponent(bar);

			// The mallet that is driven by the roller
			auto mallet = std::make_shared<CShape>();
			wid = 8;
			mallet->Rectangle(-wid / 2, 0, wid, 100);
			mallet->SetImage(L"images/mallet.png");
			AddComponent(mallet);
			roller->AddPart(mallet);

			std::shared_ptr<CWavChannel> channel;

			//
			// Specifics for each one of the bells
			//
			switch (i)
			{
			case 0:
			default:
				bar->SetImage(L"images/bar-red.png");
				channel = GetWavPlayer()->CreateChannel(L"audio/bell-c1.wav");

				cam->AddPin(1);
				cam->AddPin(2);
				cam->AddPin(4);
				break;

			case 1:
				bar->SetImage(L"images/bar-grn.png");
				channel = GetWavPlayer()->CreateChannel(L"audio/bell-e1.wav");
				cam->AddPin(3);
				cam->AddPin(5);
				cam->AddPin(9);
				break;

			case 2:
				bar->SetImage(L"images/bar-pur.png");
				channel = GetWavPlayer()->CreateChannel(L"audio/bell-e1.wav");

				cam->AddPin(6);
				cam->AddPin(8);
				cam->AddPin(13);
				break;

			case 3:
				bar->SetImage(L"images/bar-yel.png");
				channel = GetWavPlayer()->CreateChannel(L"audio/bell-g1.wav");
				cam->AddPin(4);
				cam->AddPin(7);
				cam->AddPin(11);
				break;

			case 4:
				bar->SetImage(L"images/bar-cyan.png");
				channel = GetWavPlayer()->CreateChannel(L"audio/bell-a1.wav");
				cam->AddPin(10);
				cam->AddPin(12);
				cam->AddPin(15);
				break;
			}

			roller->SetAudioChannel(channel);

			// The Build function creates the cam after the pins have been added
			cam->Build();

		}

		// The flag
		auto flag = std::make_shared<CShape>();
		flag->GetSink()->SetComponent(flag);
		flag->AddPoint(-50, 0);
		flag->AddPoint(-50, -100);
		flag->AddPoint(5, -100);
		flag->AddPoint(5, 0);
		flag->SetImage(L"images/flag.png");
		flag->SetPosition(pulley3->GetPosition().X, pulley3->GetPosition().Y);
		AddComponent(flag);

		pulley3->GetSource()->AddSink(flag->GetSink());
	}
	else if (mMachine == 2)
	{
		mComponents.clear();

		// The base
		auto base = std::make_shared<CShape>();
		int wid = 550;
		base->Rectangle(-wid / 2, 0, wid, 40);
		base->SetImage(L"images/base.png");
		AddComponent(base);

		// The motor
		auto motor = std::make_shared<CMotor>();
		motor->SetPosition(0, -38);
		motor->SetSpeed(1.0);
		AddComponent(motor);

		auto post1 = std::make_shared<CShape>();
		post1->Rectangle(-150, -40, 20, 120);
		post1->SetColor(Gdiplus::Color::Green);
		AddComponent(post1);

		auto post2 = std::make_shared<CShape>();
		post2->Rectangle(150, -40, 20, 120);
		post2->SetColor(Gdiplus::Color::BlueViolet);
		AddComponent(post2);

		auto post3 = std::make_shared<CShape>();
		post3->Rectangle(80, -40, 15, 180);
		post3->SetColor(Gdiplus::Color::DarkOrange);
		AddComponent(post3);

		// The pulley driven by the motor
		// Radius=15pixels
		auto pulley1 = std::make_shared<CPulley>(15);
		pulley1->GetSink()->SetComponent(pulley1);
		pulley1->SetImage(L"images/pulley2.png");
		pulley1->SetPosition(0, -38 - CMotor::Size / 2);
		pulley1->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley1);

		motor->GetSource()->AddSink(pulley1->GetSink());

		// The pulley on the first post. Driven by the motor pulley.
		// Radius=40pixels
		auto pulley2 = std::make_shared<CPulley>(40);
		pulley2->GetSink()->SetComponent(pulley2);
		pulley2->SetImage(L"images/pulley.png");
		pulley2->SetPosition(-140, -150);
		pulley2->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley2);
		pulley1->Drive(pulley2);

		auto pulley3 = std::make_shared<CPulley>(15);
		pulley3->GetSink()->SetComponent(pulley3);
		pulley3->SetImage(L"images/pulley2.png");
		pulley3->SetPosition(-140, -150);
		AddComponent(pulley3);
		pulley2->GetSource()->AddSink(pulley3->GetSink());

		auto pulley4 = std::make_shared<CPulley>(40);
		pulley4->GetSink()->SetComponent(pulley4);
		pulley4->SetImage(L"images/pulley.png");
		pulley4->SetPosition(160, -150);
		pulley4->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley4);
		pulley3->Drive(pulley4);

		// Pulley directly driven by that pulley
		// Radius=15px
		auto pulley5 = std::make_shared<CPulley>(15);
		pulley5->GetSink()->SetComponent(pulley5);
		pulley5->SetImage(L"images/pulley2.png");
		pulley5->SetPosition(160, -150);
		AddComponent(pulley5);
		pulley4->GetSource()->AddSink(pulley5->GetSink());

		auto pulley6 = std::make_shared<CPulley>(40);
		pulley6->GetSink()->SetComponent(pulley6);
		pulley6->SetImage(L"images/pulley.png");
		pulley6->SetPosition(87, -210);
		pulley6->SetPhase(0.1);	// Rotate it a little bit
		AddComponent(pulley6);
		pulley5->Drive(pulley6);

		// A cam
		auto cam = std::make_shared<CCam>(20, 16);
		cam->GetSink()->SetComponent(cam);
		cam->SetImage(L"images/hammered-copper1.png", true);
		cam->SetPhase(-0.25);
		cam->SetPosition(87, -210);
		cam->AddPin(5);
		cam->AddPin(1);
		cam->AddPin(6);
		cam->Build();
		AddComponent(cam);
		pulley6->GetSource()->AddSink(cam->GetSink());

		// A roller that rides on the cam
			// Radius is 4 pixels.
			// The angle is 0.25, placing it at the top of the cam
		auto roller = std::make_shared<CRoller>(4, 0.25);
		roller->SetImage(L"images/roller.png");
		roller->SetCam(cam);
		AddComponent(roller);

		// A bar that represents the bell
		auto bar = std::make_shared<CShape>();
		bar->Rectangle(-24 / 2, 0, 24, 108);
		bar->SetPosition(87, -275);
		bar->SetImage(L"images/bar-red.png");
		AddComponent(bar);
		
		// The mallet that is driven by the roller
		auto mallet = std::make_shared<CShape>();
		wid = 8;
		mallet->Rectangle(-wid / 2, 0, wid, 100);
		mallet->SetImage(L"images/mallet.png");
		AddComponent(mallet);
		roller->AddPart(mallet);

		std::shared_ptr<CWavChannel> channel;
		channel = GetWavPlayer()->CreateChannel(L"audio/bell-c1.wav");
		roller->SetAudioChannel(channel);
		
		// The flag
		auto flag = std::make_shared<CShape>();
		flag->GetSink()->SetComponent(flag);
		flag->AddPoint(-50, 0);
		flag->AddPoint(-50, -100);
		flag->AddPoint(5, -100);
		flag->AddPoint(5, 0);
		flag->SetImage(L"images/flag.png");
		flag->SetPosition(pulley3->GetPosition().X, pulley3->GetPosition().Y);
		AddComponent(flag);

		pulley3->GetSource()->AddSink(flag->GetSink());
	}
}

void CActualMachine::AddComponent(std::shared_ptr<CComponent> component)
{
	mComponents.push_back(component);
}

void CActualMachine::SetTime(double time)
{
	for (auto component : mComponents)
	{
		component->SetTime(time * mSpeed);
	}
}
